"""Minimal working example for conda-smithy submodule error https://github.com/conda-forge/conda-smithy/issues/1516."""
__version__ = "v1.0.0"
